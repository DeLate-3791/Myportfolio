require 'sinatra'
require 'httparty'
require 'json'
require 'webrick'
require 'webrick/https'
require 'openssl'
set :port, 4567
set :server, 'webrick'
# publicディレクトリ内のファイルを提供するための設定
set :public_folder, File.dirname(__FILE__) + '/public'

class MyApp < Sinatra::Base
  # ルートパスへのGETリクエストを処理する
  get '/' do
    # views/index.erbをレンダリングして返す
    erb :index
  end

  # ユーザーが検索フォームを送信したときの処理
  get '/search' do
    # ユーザーが指定した検索半径を取得
    radius = params[:radius]
    page = params[:page].to_i
    page = 1 if page.zero?  # ページ番号が0の場合はデフォルトで1ページ目

    # ユーザーの現在地を取得（ここでは仮に固定の緯度経度を使用）
    latitude = 35.4808607
    longitude =  133.068039

    # ホットペッパーAPIにリクエストを送信してレストラン情報を取得
    response = HTTParty.get("https://webservice.recruit.co.jp/hotpepper/gourmet/v1/?key=10de51dd5993251e&lat=#{latitude}&lng=#{longitude}&range=#{radius}&start=#{(page.to_i - 1) * 10}&count=10&format=json")
    
    # APIからのレスポンスを確認
    if  response.success?
      # レストラン情報を表示するビューテンプレートをレンダリングして返す
      result = JSON.parse(response.body)["results"]
      restaurants = result["shop"]
      total_results = result["results_available"]
      # ページ数を計算します（1ページあたり10件表示）    
      total_pages = (total_results.to_f / 10).ceil 
      erb :search_results, locals: { restaurants: restaurants, page: page, total_pages: total_pages }
    else
      # エラーメッセージを表示
      erb :error
    end

  end

  #店舗詳細画面へのルート
  get '/restaurants/:id' do
    # パラメータから店舗IDを取得
    restaurant_id = params[:id]
    #ホットペッパーAPIに店舗IDを含めてリクエストを送信して詳細情報を取得
    response = HTTParty.get("https://webservice.recruit.co.jp/hotpepper/gourmet/v1/?key=10de51dd5993251e&id=#{restaurant_id}&format=json")

    #APIからのレスポンスを確認
    if response.success?
    #APIからのレスポンスをJSON形式で取得し、必要な情報を抽出
    restaurant = JSON.parse(response.body)["results"]["shop"][0]
    #レストランの詳細情報を表示するビューテンプレートをレンダリングして返す
    erb :restaurant_detail, locals: { restaurant: restaurant }
    else
    #エラーメッセージを表示
    erb :error
    end

  end

  # 位置情報を受け取るためのルート
  post '/location' do
  latitude = params[:latitude]
  longitude = params[:longitude]
  
  # 検索結果ページにリダイレクトする
  redirect "/search?latitude=#{latitude}&longitude=#{longitude}&radius=#{params[:radius]}&page=1"
  content_type :json
  { latitude: latitude, longitude: longitude }.to_json

end

end

Rack::Handler::WEBrick.run MyApp
