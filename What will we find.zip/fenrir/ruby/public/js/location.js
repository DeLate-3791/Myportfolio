document.addEventListener('DOMContentLoaded', function() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(successCallback, errorCallback);
    } else {
      console.error('Geolocation is not supported by this browser.');
    }
  });
  
  function successCallback(position) {
    const latitude = position.coords.latitude;
    const longitude = position.coords.longitude;
    console.log('Latitude:', latitude);
    console.log('Longitude:', longitude);
  
    // サーバーに取得した位置情報を送信する（Ajaxを使用）
  fetch('/location', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    // パラメータとして緯度と経度を送信
    params: {
      latitude: latitude,
      longitude: longitude
    }
  })
  .then(response => {
    if (!response.ok) {
      throw new Error('Failed to send location data to server.');
    }
    console.log('Location data sent to server.');
  })
}
  
  function errorCallback(error) {
    console.error('Error getting current position:', error);
  }
  